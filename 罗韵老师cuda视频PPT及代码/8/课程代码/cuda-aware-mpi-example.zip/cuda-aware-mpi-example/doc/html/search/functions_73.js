var searchData=
[
  ['setdeviceafterinit',['SetDeviceAfterInit',['../CUDA__Aware__MPI_8c.html#aa8cb031e8cba7840a96582f530283fd5',1,'SetDeviceAfterInit(int rank):&#160;CUDA_Aware_MPI.c'],['../CUDA__Normal__MPI_8c.html#aa8cb031e8cba7840a96582f530283fd5',1,'SetDeviceAfterInit(int rank):&#160;CUDA_Normal_MPI.c'],['../Jacobi_8h.html#aa8cb031e8cba7840a96582f530283fd5',1,'SetDeviceAfterInit(int rank):&#160;CUDA_Aware_MPI.c']]],
  ['setdevicebeforeinit',['SetDeviceBeforeInit',['../CUDA__Aware__MPI_8c.html#ac7925a5469b04c01679b20577671c975',1,'SetDeviceBeforeInit():&#160;CUDA_Aware_MPI.c'],['../CUDA__Normal__MPI_8c.html#ac7925a5469b04c01679b20577671c975',1,'SetDeviceBeforeInit():&#160;CUDA_Normal_MPI.c'],['../Jacobi_8h.html#ac7925a5469b04c01679b20577671c975',1,'SetDeviceBeforeInit():&#160;CUDA_Aware_MPI.c']]]
];
