var searchData=
[
  ['use_5ffloat',['USE_FLOAT',['../Jacobi_8h.html#a5a03415e5a2d7bdc6ce680c47ddc156a',1,'Jacobi.h']]]
];
