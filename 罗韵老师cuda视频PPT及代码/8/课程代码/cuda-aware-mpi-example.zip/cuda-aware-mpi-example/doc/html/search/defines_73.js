var searchData=
[
  ['status_5ferr',['STATUS_ERR',['../Jacobi_8h.html#a23205a6a97096d57a247794f5e250963',1,'Jacobi.h']]],
  ['status_5fok',['STATUS_OK',['../Jacobi_8h.html#a2403320c41f08e7567cb169de5db66b3',1,'Jacobi.h']]]
];
