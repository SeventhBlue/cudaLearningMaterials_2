var searchData=
[
  ['jacobicomputekernel',['JacobiComputeKernel',['../Device_8cu.html#abde66d396480d3d7cf52227a4bf204ed',1,'Device.cu']]]
];
