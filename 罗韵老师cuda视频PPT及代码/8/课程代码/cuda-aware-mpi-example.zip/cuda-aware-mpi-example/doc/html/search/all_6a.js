var searchData=
[
  ['jacobi_2ec',['Jacobi.c',['../Jacobi_8c.html',1,'']]],
  ['jacobi_2eh',['Jacobi.h',['../Jacobi_8h.html',1,'']]],
  ['jacobi_5fmax_5floops',['JACOBI_MAX_LOOPS',['../Jacobi_8h.html#a3941d7542ce359c2489df632b4893aee',1,'Jacobi.h']]],
  ['jacobi_5ftolerance',['JACOBI_TOLERANCE',['../Jacobi_8h.html#a3bfda2a5c101b1a0762152713cda5aa8',1,'Jacobi.h']]],
  ['jacobicomputekernel',['JacobiComputeKernel',['../Device_8cu.html#abde66d396480d3d7cf52227a4bf204ed',1,'Device.cu']]]
];
