var searchData=
[
  ['env_5flocal_5frank',['ENV_LOCAL_RANK',['../Jacobi_8h.html#a1cf673c1febd6ac97dd8aefadf00b5f7',1,'Jacobi.h']]]
];
