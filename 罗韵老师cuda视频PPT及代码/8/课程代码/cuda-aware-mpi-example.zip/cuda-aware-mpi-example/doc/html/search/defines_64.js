var searchData=
[
  ['default_5fdomain_5fsize',['DEFAULT_DOMAIN_SIZE',['../Jacobi_8h.html#ae7bacf72b151d28a9a4c55d10db0fa0b',1,'Jacobi.h']]]
];
