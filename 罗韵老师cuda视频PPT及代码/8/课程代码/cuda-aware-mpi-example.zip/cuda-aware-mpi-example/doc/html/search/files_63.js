var searchData=
[
  ['cuda_5faware_5fmpi_2ec',['CUDA_Aware_MPI.c',['../CUDA__Aware__MPI_8c.html',1,'']]],
  ['cuda_5fnormal_5fmpi_2ec',['CUDA_Normal_MPI.c',['../CUDA__Normal__MPI_8c.html',1,'']]]
];
